#include <iostream>
using namespace std;
int main()
{
    char h = 'a';

    cout << h << endl;
    cout << h - '1' << endl;
    cout << h - '2' << endl;
    
    return 0;
}